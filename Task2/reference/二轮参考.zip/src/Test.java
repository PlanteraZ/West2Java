import Cat.BlackCat;
import Cat.Cat;
import Cat.OrangeCat;
import CatCafe.MyCatCafe;
import CatCafeException.CatNotFoundException;
import CatCafeException.InsufficientBalanceException;
import Customer.Customer;

import java.net.HttpURLConnection;
import java.time.LocalDate;
import java.util.HashMap;

public class Test {
    public static void main(String[] args) {

        MyCatCafe myCatCafe=new MyCatCafe(750);
        try{
        myCatCafe.buyCat(new BlackCat("小黑",6,false));
        myCatCafe.buyCat(new OrangeCat("小橘",5,true,false));
        myCatCafe.buyCat(new OrangeCat("大橘",7,true,true));
        myCatCafe.buyCat(new BlackCat("大黑",8,false));//这个会钱不够
        }catch (RuntimeException e){
            e.printStackTrace();
        }
        Customer customer1=new Customer("小白",5, LocalDate.now());
        Customer customer2=new Customer("小绿",3,LocalDate.now());
        Customer customer3=new Customer("小红",9,LocalDate.of(2021,10,29));
        myCatCafe.serve(customer1);
        myCatCafe.serve(customer2);
        myCatCafe.serve(customer3);
        myCatCafe.close();

        MyCatCafe myCatCafe2=new MyCatCafe(0);
        try{
            myCatCafe2.buyCat(new BlackCat("小黑",4,false));
        }catch (InsufficientBalanceException e){
            e.printStackTrace();
        }
        try {
            myCatCafe2.serve(customer1);
        }catch (CatNotFoundException e){
            e.printStackTrace();
        }
        myCatCafe2.close();//这条可能会比上面的printStackTrace先输出，因为printStackTrace里面走的是错误输出流System.err，和标准输出流不太一样所以输出顺序可能会有所不同



    }
}
