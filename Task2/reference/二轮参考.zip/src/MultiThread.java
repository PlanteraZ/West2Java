/*
* 多线程实现方式1
* */
public class MultiThread {
    final static Object lock = new Object();
    //lock是个Object类型，其实叫啥都没事，主要是让synchronize知道要锁哪个玩意
    static int[] arr1;
    static int[] arr2;
    static int count1 = 0;
    static int count2 = 0;


    static class MyThread3 extends Thread {
        @Override
        public void run() {
            synchronized (lock) {
                while (count1 != arr1.length) {


                    System.out.println("T3：" + arr1[count1++]);


                    lock.notifyAll();
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                lock.notify();
            }

        }
    }

    static class MyThread4 extends Thread {
        @Override
        public void run() {
            synchronized (lock) {
                while (count2 != arr2.length) {


                    System.out.println("T4：" + arr2[count2++]);

                    lock.notifyAll();
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                lock.notify();
            }

        }
    }

    public static void crossPrint(int[] arr1, int[] arr2) {
        MultiThread.arr1 = arr1;
        MultiThread.arr2 = arr2;
        MyThread3 t3 = new MyThread3();
        MyThread4 t4 = new MyThread4();
        t3.start();
        t4.start();
        try {
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        int[] myArr1 = {1, 2, 3, 4, 5};
        int[] myArr2 = {6, 7, 8, 9, 10};
        crossPrint(myArr1, myArr2);
    }
}

