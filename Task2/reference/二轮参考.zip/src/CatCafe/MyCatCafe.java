package CatCafe;

import Cat.Cat;
import CatCafeException.CatNotFoundException;
import CatCafeException.InsufficientBalanceException;
import Customer.Customer;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyCatCafe implements CatCafe{
    private double balance;
    private List<Cat> catList;
    private List<Customer> customerList;

    public MyCatCafe(double money) {
        this.balance = money;
        catList=new ArrayList<>();
        customerList=new ArrayList<>();
    }

    @Override
    public void buyCat(Cat cat) throws InsufficientBalanceException{
        if(cat.getPrice()> balance){
            throw new InsufficientBalanceException("余额不足");
        }
        catList.add(cat);
        balance-=cat.getPrice();
    }

    @Override
    public void serve(Customer customer) throws CatNotFoundException{
        if(catList.size()==0){
            throw new CatNotFoundException("一只猫也没有！");
        }
        customerList.add(customer);//注意逻辑：不要一只猫也没有也把顾客也加入到list里去！
        System.out.println("顾客"+customer.getName()+"开始rua猫...");
        Random random=new Random(Instant.now().toEpochMilli());//取当前时间为随机数种子
        for(int i=0;i<customer.getRuaCount();i++){
            balance+=15;
            System.out.println("当前顾客正在rua:"+catList.get(random.nextInt(catList.size())));
        }

    }

    @Override
    public void close() {
        double profit=0;
        LocalDate curTime=LocalDate.now();
        for(Customer customer:customerList){
            if(customer.getArriveDate().isEqual(curTime)){
                System.out.println(customer);
                profit+=customer.getRuaCount()*15;
            }
        }
        System.out.println(curTime+"利润为: "+profit);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public List<Cat> getCatList() {
        return catList;
    }

    public void setCatList(List<Cat> catList) {
        this.catList = catList;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
}
