package CatCafe;

import Cat.Cat;
import Customer.Customer;

public interface CatCafe {
    void buyCat(Cat cat);
    void serve(Customer customer);
    void close();

}
