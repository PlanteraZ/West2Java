package Cat;

public class BlackCat extends Cat {
    public BlackCat(String name, int age, boolean isMale) {
        super(name, age, isMale,350);
    }

    @Override
    public String toString() {
        return "BlackCat{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", isMale=" + isMale +
                ", price=" + price +
                '}';
    }
}
