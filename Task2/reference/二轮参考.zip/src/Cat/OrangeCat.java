package Cat;

public class OrangeCat extends Cat{
    protected boolean isFat;

    public OrangeCat(String name, int age, boolean isMale,boolean isFat) {
        super(name, age, isMale,200);
        this.isFat=isFat;
    }

    @Override
    public String toString() {
        return "OrangeCat{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", isMale=" + isMale +
                ", price=" + price +
                ", isFat=" + isFat +
                '}';
    }

    public boolean isFat() {
        return isFat;
    }

    public void setFat(boolean fat) {
        isFat = fat;
    }
}
