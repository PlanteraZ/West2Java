package CatCafeException;

public class CatNotFoundException extends RuntimeException{
    public CatNotFoundException() {
        super();
        System.out.println("异常: 猫的数量小于等于0");
    }
    public CatNotFoundException(String msg){
        super(msg);
    }

}
