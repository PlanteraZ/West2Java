package CatCafeException;

public class InsufficientBalanceException extends RuntimeException{
    public InsufficientBalanceException() {
        super();
        System.out.println("异常: 余额不足");
    }
    public InsufficientBalanceException(String message) {
        super(message);
    }
}
