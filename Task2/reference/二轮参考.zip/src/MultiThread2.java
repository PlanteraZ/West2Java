import java.util.concurrent.locks.LockSupport;
/*
* 多线程实现方式2(1比较常规）
* */
public class MultiThread2 {
    Thread x1 = null;
    Thread x2 = null;

    public void PairPrint(int[] n1, int[] n2) {
        x1 = new Thread(() -> {
            for (int i : n1) {
                System.out.print(i + " ");
                LockSupport.unpark(x2);
                LockSupport.park();
            }
        });
        x2 = new Thread(() -> {
            for (int j : n2) {
                LockSupport.park();
                System.out.print(j + " ");
                LockSupport.unpark(x1);
            }
        });
        x1.start();
        x2.start();
    }


}
