public class MailRegex {
    public static boolean testRegex(String mailAddr){
        return mailAddr.matches("^[a-z0-9A-Z]+[- | a-z0-9A-Z . _]+@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-z]{2,}$");
    }

    public static void main(String[] args) {
        System.out.println(testRegex("1919810@qq.com"));
        System.out.println(testRegex("114514@fzu.edu.cn"));
        System.out.println(testRegex("hello11@example.com"));
        System.out.println(testRegex("CyberPunk2077"));
    }
}
