package Customer;

import java.time.LocalDate;

public class Customer {
    protected String name;
    protected int ruaCount;
    protected LocalDate arriveDate;

    public Customer(String name, int ruaCount, LocalDate arriveDate) {
        this.name = name;
        this.ruaCount = ruaCount;
        this.arriveDate = arriveDate;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", ruaCount=" + ruaCount +
                ", arriveDate=" + arriveDate +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRuaCount() {
        return ruaCount;
    }

    public void setRuaCount(int ruaCount) {
        this.ruaCount = ruaCount;
    }

    public LocalDate getArriveDate() {
        return arriveDate;
    }

    public void setArriveDate(LocalDate arriveDate) {
        this.arriveDate = arriveDate;
    }
}
